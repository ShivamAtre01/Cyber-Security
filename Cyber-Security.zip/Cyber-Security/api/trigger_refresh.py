import requests

try:
    response = requests.post("http://localhost:3000/refresh")
    print("Status Code:", response.status_code)
    print("Response:", response.text)
except requests.exceptions.RequestException as e:
    print("Error:", e)
