import requests
import time

FEEDS = {
    "blocklist": "http://www.blocklist.de/lists/apache.txt",
    "spamhaus": "http://www.spamhaus.org/drop/drop.txt",
    "digitalside": "https://urlhaus.abuse.ch/downloads/text/"
}

HEADERS = {
    "User-Agent": "ThreatIntelCollector/1.0"
}

RETRY_LIMIT = 3
RETRY_DELAY = 5  # seconds

def fetch_feed(name, url):
    for attempt in range(1, RETRY_LIMIT + 1):
        try:
            response = requests.get(url, headers=HEADERS, timeout=10)
            response.raise_for_status()
            print(f"[OK] Fetched {name} feed successfully.")
            return response.text
        except requests.RequestException as e:
            print(f"[!] Attempt {attempt} failed for {name}: {e}")
            time.sleep(RETRY_DELAY)
    print(f"[x] Failed to fetch {name} after {RETRY_LIMIT} retries.")
    return ""

def save_raw_feed(name, content):
    filename = f"raw_feeds/{name}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[→] Saved raw feed to {filename}")

def main():
    for name, url in FEEDS.items():
        content = fetch_feed(name, url)
        if content:
            save_raw_feed(name, content)

if __name__ == "__main__":
    import os
    os.makedirs("raw_feeds", exist_ok=True)
    main()
