import json
import re
from urllib.parse import urlparse

INPUT_FILE = "normalized_iocs.json"
OUTPUT_FILE = "enriched_filtered_iocs.json"

# Mock IP enrichment DB
MOCK_IP_DB = {
    "45.66.222.1": {"country": "US", "org": "Example Org"},
    "192.168.1.1": {"country": "Private", "org": "Local Network"},
    # Add more mocked IPs as needed
}

# Suspicious URL extensions
ALLOWED_EXTENSIONS = {".exe", ".zip", ".rar", ".scr", ".js"}

# Suspicious keywords often found in phishing URLs
SUSPICIOUS_KEYWORDS = [
    "free", "cheap", "login", "bank", "update", "click",
    "download", "secure", "account", "verify", "password",
]

# Enrich IP using mock DB
def enrich_ip(ip):
    return MOCK_IP_DB.get(ip, {"country": "Unknown", "org": "Unknown"})

# Check if URL has suspicious extension
def has_suspicious_extension(url):
    parsed = urlparse(url)
    path = parsed.path.lower()
    return any(path.endswith(ext) for ext in ALLOWED_EXTENSIONS)

# Keyword-based URL classifier
def ml_url_classifier(url):
    url_lower = url.lower()
    score = sum(1 for kw in SUSPICIOUS_KEYWORDS if re.search(r"\b" + re.escape(kw) + r"\b", url_lower))
    return "suspicious" if score > 0 else "benign"

def main():
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        iocs = json.load(f)

    enriched = []
    seen = set()

    for ioc in iocs:
        key = (ioc["type"], ioc["value"])
        if key in seen:
            continue  # Skip duplicates
        seen.add(key)

        if ioc["type"] == "ip":
            ioc["enrichment"] = enrich_ip(ioc["value"])
            enriched.append(ioc)

        elif ioc["type"] == "url":
            ioc["ml_label"] = ml_url_classifier(ioc["value"])
            ioc["has_suspicious_extension"] = has_suspicious_extension(ioc["value"])
            enriched.append(ioc)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(enriched, f, indent=2)

    print(f"[✓] Enriched and labeled {len(enriched)} IOCs saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
