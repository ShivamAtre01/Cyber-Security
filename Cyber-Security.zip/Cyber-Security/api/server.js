const { exec } = require('child_process');
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// POST /refresh – triggers the Python ingestion + enrichment pipeline
app.post('/refresh', (req, res) => {
    const command = 'python ingest_feeds.py && python normalize.py && python enrich_filter.py';

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error("Refresh error:", error.message);
            return res.status(500).json({ error: 'Failed to refresh IOCs' });
        }
        return res.json({ message: 'IOC data refreshed successfully' });
    });
});

// GET /iocs – return all or filtered IOCs
app.get('/iocs', (req, res) => {
    try {
        const rawData = fs.readFileSync('enriched_filtered_iocs.json', 'utf-8');
        let data = JSON.parse(rawData);

        const { type, source } = req.query;

        // Filter by type: 'ip' or 'url'
        if (type) {
            data = data.filter(ioc => ioc.type === type);
        }

        // Filter by source: e.g., 'spamhaus', 'blocklist', etc.
        if (source) {
            data = data.filter(ioc => ioc.source.toLowerCase().includes(source.toLowerCase()));
        }

        res.json(data);
    } catch (err) {
        console.error("Error loading IOCs:", err.message);
        res.status(500).json({ error: 'Failed to load IOC data' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Threat Intel API running at http://localhost:${PORT}`);
});
