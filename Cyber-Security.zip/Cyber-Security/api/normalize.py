import os
import json
from datetime import datetime

RAW_FEEDS_DIR = "raw_feeds"
OUTPUT_FILE = "normalized_iocs.json"

def normalize_blocklist(content):
    iocs = []
    for line in content.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            iocs.append({
                "type": "ip",
                "value": line,
                "source": "blocklist",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            })
    return iocs

def normalize_spamhaus(content):
    iocs = []
    for line in content.splitlines():
        line = line.strip()
        if line and not line.startswith(";"):
            ip = line.split(";")[0].strip()
            iocs.append({
                "type": "ip",
                "value": ip,
                "source": "spamhaus",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            })
    return iocs

def normalize_digitalside(content):
    iocs = []
    for line in content.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            iocs.append({
                "type": "url",
                "value": line,
                "source": "digitalside",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            })
    return iocs

def main():
    all_iocs = []

    # Read blocklist
    path = os.path.join(RAW_FEEDS_DIR, "blocklist.txt")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            all_iocs.extend(normalize_blocklist(f.read()))

    # Read spamhaus
    path = os.path.join(RAW_FEEDS_DIR, "spamhaus.txt")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            all_iocs.extend(normalize_spamhaus(f.read()))

    # Read digitalside
    path = os.path.join(RAW_FEEDS_DIR, "digitalside.txt")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            all_iocs.extend(normalize_digitalside(f.read()))

    # Save to output file
    with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
        json.dump(all_iocs, out, indent=2)
    print(f"[✓] Normalized {len(all_iocs)} IOCs saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
